from discord.ext import commands
import discord
from utils.mongo import Document


class FiveMLinks(Document):
    pass
