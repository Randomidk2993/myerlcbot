<p align="center">
  <img src="assets/ermlogo.png" alt="ERM Bot Logo">
</p>


<h1 align="center">ERM | Emergency Response Management</h1>

<p align="center">Emergency Response Management (ERM for short) is a bot designed for servers within the Roblox roleplay community. This repository contains all necessary information and resources for the bot. </p>

## Essential Links
- [Bot Invitation](https://canary.discord.com/api/oauth2/authorize?client_id=978662093408591912&permissions=8&scope=applications.commands%20bot)
- [Support Server](https://discord.gg/FAC629TzBy)
- [Official Website](https://ermbot.xyz/)
- [Desktop Download](https://ermbot.xyz/download)

## Licensing
ERM is licensed under the Attribution-NonCommercial-ShareAlike (CC BY-NC-SA) license. This license allows for the copy, distribution, and creation of adaptations of the material for non-commercial purposes, as long as proper attribution is given to the original creator and any adaptations are licensed under the same terms.

[![License](https://licensebuttons.net/l/by-nc-sa/3.0/88x31.png)](https://top.gg/bot/978662093408591912)

The CC BY-NC-SA license requires the following elements:
- BY: Credit must be given to the original creator
- NC: The material can only be used for non-commercial purposes
- SA: Adaptations must be licensed under the same terms


[![Better Stack Badge](https://uptime.betterstack.com/status-badges/v1/monitor/insx.svg)](https://uptime.betterstack.com/?utm_source=status_badge)
[![CodeFactor](https://www.codefactor.io/repository/github/mikeyusersrec/erm/badge)](https://www.codefactor.io/repository/github/mikeyusersrec/erm)
